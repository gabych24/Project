from django.db import models
from django.db import models


class Vacation(models.Model):  
    vid = models.CharField(max_length=20)  
    vdesc = models.CharField(max_length=100)  
    vstartdate = models.DateField()  
    venddate = models.DateField()
    class Meta:  
        db_table = "Vacation"  


# Create your models here.
